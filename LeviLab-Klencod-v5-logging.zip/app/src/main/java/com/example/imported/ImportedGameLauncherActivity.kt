package com.example.imported

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ImportedGameLauncherActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ImportedGameScreen()
                }
            }
        }
    }
}

private fun readLogTail(context: Context): String {
    return try {
        val f = ImportedApkStore.runtimeLogFile(context)
        if (!f.exists()) "(لا يوجد سجل بعد)" else f.readText().takeLast(6000)
    } catch (t: Throwable) {
        "(تعذر قراءة السجل)"
    }
}

@Composable
private fun ImportedGameScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var versions by remember { mutableStateOf(ImportedApkStore.listVersions(context)) }
    var activeId by remember { mutableStateOf(ImportedApkStore.activeId(context)) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf(0f) }
    var status by remember { mutableStateOf("") }
    var logText by remember { mutableStateOf(readLogTail(context)) }

    fun refresh() {
        versions = ImportedApkStore.listVersions(context)
        activeId = ImportedApkStore.activeId(context)
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            busy = true
            progress = 0f
            status = "بدأ الاستيراد..."
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    ImportedApkStore.importFromUri(context, uri) { msg, p ->
                        status = msg
                        progress = p
                    }
                }
                result.onSuccess {
                    status = "تم استيراد ${it.packageName} v${it.versionName} وتفعيله"
                }.onFailure {
                    status = "فشل الاستيراد: ${it.message}"
                }
                refresh()
                busy = false
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("تشغيل ماين كرافت من ملف APK", style = MaterialTheme.typography.titleLarge)
        Text(
            "استورد ملفات APK للنسخة التجريبية (أكثر من إصدار)، وفعّل الإصدار اللي تبيه. " +
                "كل إصدار يُحفظ نسخة خاصة داخل التطبيق ولا يتأثر ماين كرافت المثبّت.",
            style = MaterialTheme.typography.bodyMedium
        )

        Button(
            onClick = { picker.launch(arrayOf("application/vnd.android.package-archive", "application/octet-stream", "*/*")) },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("إضافة إصدار (اختيار ملف APK)") }

        if (busy) {
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
        }
        if (status.isNotEmpty()) Text(status, style = MaterialTheme.typography.bodyMedium)

        Text("مكتبة الإصدارات (${versions.size})", style = MaterialTheme.typography.titleMedium)
        if (versions.isEmpty()) {
            Text("لا يوجد إصدارات مستوردة بعد.", style = MaterialTheme.typography.bodyMedium)
        }
        versions.forEach { v ->
            val isActive = v.id == activeId
            Surface(
                tonalElevation = 3.dp,
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        "${v.packageName}\nالإصدار ${v.versionName} (${v.versionCode}) • ${v.apkSizeBytes / (1024 * 1024)} MB",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (isActive) {
                            Text(
                                "✓ المفعّل",
                                color = MaterialTheme.colorScheme.primary,
                                style = MaterialTheme.typography.titleSmall
                            )
                        } else {
                            Button(
                                onClick = {
                                    ImportedApkStore.setActive(context, v.id)
                                    refresh()
                                    status = "تم تفعيل ${v.versionName}"
                                },
                                enabled = !busy
                            ) { Text("تفعيل") }
                        }
                        OutlinedButton(
                            onClick = {
                                ImportedApkStore.deleteVersion(context, v.id)
                                refresh()
                                status = "تم حذف ${v.versionName}"
                            },
                            enabled = !busy
                        ) { Text("حذف") }
                    }
                }
            }
        }

        Button(
            onClick = {
                McBootstrap.log(context, "--- طلب تشغيل من الواجهة (الإصدار المفعّل: $activeId) ---")
                scope.launch {
                    // Make sure a previous game process doesn't keep an old version loaded
                    McBootstrap.killGameProcess(context)
                    delay(400)
                    try {
                        context.startActivity(
                            Intent().setClassName(context.packageName, ImportedApkStore.EXPECTED_ACTIVITY)
                        )
                    } catch (t: Throwable) {
                        status = "تعذر التشغيل: ${t.javaClass.simpleName}: ${t.message}"
                    }
                }
            },
            enabled = activeId != null && !busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("تشغيل الإصدار المفعّل داخل التطبيق") }

        Spacer(modifier = Modifier.height(4.dp))
        Text("سجل التشغيل", style = MaterialTheme.typography.titleMedium)
        OutlinedButton(
            onClick = { logText = readLogTail(context) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("تحديث السجل") }
        OutlinedButton(
            onClick = {
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("LeviLab MC log", readLogTail(context)))
                Toast.makeText(context, "تم نسخ السجل", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("نسخ السجل") }
        Text(logText, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
    }
}
